
class not2DError(Exception):
# Error for 1D list
    def __str__(self):
        return '[ERROR]: list is not 2D.'

class unevenListError(Exception):
# Error for uneven list
    def __str__(self):
        return '[ERROR]: inner lists are not same in length.'

class improperMatrixError(Exception):
# Error for incompatible matmul pair
    def __str__(self):
        return '[ERROR]: [a][b]*[c][d] not b==c.'


def mul1d(arr1,arr2):
    # arr1 * arr2
    # [1,2,3] * [4,5,6]
    # return  1*4 + 2*5 + 3*6
    sum = 0
    for i in range(len(arr1)):
        sum+=arr1[i]*arr2[i]
    return sum

class list_D2(list):
    def __init__(self,arr):
        
        ### YOUR CODE HERE ###
        invalid=False
        for value in arr:
            if not isinstance(value,list):
                invalid=True
                break
            else:
                for target in value:
                    if isinstance(target,list):
                        invalid=True
                        break
        if invalid:
            raise  not2DError()

        len_arr=[]
        for lst in arr:
            len_arr.append(len(lst))
        
        if len_arr.count(len_arr[0])!=len(len_arr):
            raise unevenListError()

        self.arr=arr
    
        ######

        self.extend(arr)

    def __str__(self):

        ### YOUR CODE HERE ###
        a=str(len(self.arr))
        b=str(len(self.arr[0]))
        
        return ('list_2D: '+a+'*'+b)

        ######

    def transpose(self):

        ### YOUR CODE HERE ###
        transposed_list = list(map(list, zip(*self.arr)))

        return list_D2(transposed_list)
        
        ######


    def __matmul__(self, others):
        
        ### YOUR CODE HERE ###
        if len(self.arr[0])!=len(others.arr):
            raise improperMatrixError()
        result=[]
        for i in range(len(self.arr)):
            row_result=[]
            for j in range(len(others.arr[0])):
                sum=0
                for k in range(len(others.arr)):
                    sum+=self.arr[i][k]*others.arr[k][j]
                row_result.append(sum)
            result.append(row_result)
        
        return list_D2(result)

        ######

    def avg(self):

        ### YOUR CODE HERE ###

        total_sum = 0
        total_elements = 0

        for row in self.arr:
            for element in row:
                total_sum += element
                total_elements += 1

        return total_sum / total_elements

        ######
