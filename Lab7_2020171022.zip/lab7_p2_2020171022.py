def count_alphabets(file_path):
    with open(file_path, 'r') as file:
        text = file.read()

    
    alphabet_counts = {}
    for char in text:
        if char.isalpha():
            char = char.upper()  
            alphabet_counts[char] = alphabet_counts.get(char, 0) + 1

    alphabet_counts_list = list(alphabet_counts.items())

    alphabet_counts_list.sort(key=lambda x: x[1], reverse=True)

    lst=[]
    for item in alphabet_counts_list:
        lst.append(item[0])
    print(lst)

file_path = 'input_7_2.txt'

count_alphabets(file_path)
