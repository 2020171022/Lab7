import re
file=open('input_7_1.txt')
data=file.read()

find=re.findall(r'def\s\w+\(',data)
functions=[]
for word in find:
    functions.append(word[4:-1])

def_pos={}
call_pos={}
for word in functions:
    call_pos[word]=[]

for i in range(len(find)):
    file.seek(0)
    count=1
    for line in file:
        if find[i] in line:
            def_pos[functions[i]]=count
        count+=1

for word in functions:
    file.seek(0)
    count=1
    for line in file:
        match=re.search(r'\W'+word+r'\('," "+line)
        if match:
            if def_pos[word]!=count:
                call_pos[word].append(count)
        count+=1

for word in functions:
    call_pos[word].append(def_pos[word])
    
for key,value in call_pos.items():
    print(key,": def in ",value[-1],", calls in ",value[:-1],sep="")
